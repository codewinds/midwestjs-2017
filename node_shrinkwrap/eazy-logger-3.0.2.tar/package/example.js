var l = require('./out');

console.log(l);
