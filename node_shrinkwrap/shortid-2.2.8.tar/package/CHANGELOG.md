# Change Log
This project adheres to [Semantic Versioning](http://semver.org/).

## 2.2.8
* Clean npm package from unnecessary files.
