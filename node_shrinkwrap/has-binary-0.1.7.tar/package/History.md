
0.1.7 / 2015-11-18
==================

  * fix toJSON [@jderuere]
  * fix `global.isBuffer` usage [@tonetheman]
  * fix tests on modern versions of node
  * bump mocha

0.1.6 / 2015-01-24
==================

 * fix "undefined function" bug when iterating
   an object created with Object.create(null) [gunta]

0.1.5 / 2014-09-04
==================

 * prevent browserify from bundling `Buffer`
