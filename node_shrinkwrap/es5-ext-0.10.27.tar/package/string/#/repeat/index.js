"use strict";

module.exports = require("./is-implemented")()
	? String.prototype.repeat
	: require("./shim");
