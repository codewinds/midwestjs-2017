1.0.4 / 2015-01-29
=================
  * If @@toStringTag is not present, use the old-school Object#toString test.

1.0.3 / 2015-01-29
=================
  * Refactor to aid optimization of non-try/catch code.

1.0.2 / 2015-01-29
=================
  * Fix broken package.json

1.0.1 / 2015-01-29
=================
  * Add early exits for typeof "string", or typeof not "object".

1.0.0 / 2015-01-29
=================
  * Initial release.
