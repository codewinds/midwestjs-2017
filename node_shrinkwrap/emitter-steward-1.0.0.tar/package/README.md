##emitter-steward [![Build Status](https://travis-ci.org/shakyShane/emitter-steward.svg?branch=master)](https://travis-ci.org/shakyShane/emitter-steward)

> allow emitters in 1 second intervals
