
This example shows how you can use the `connect-gzip-static` middleware 
to serve already-gzipped assets.