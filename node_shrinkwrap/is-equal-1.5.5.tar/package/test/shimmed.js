'use strict';

require('es6-shim');

require('./why');

require('./native');
