'use strict';

require('core-js');

require('./why');

require('./native');
