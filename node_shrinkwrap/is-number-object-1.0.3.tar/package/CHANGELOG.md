1.0.3 / 2015-01-29
=================
  * If @@toStringTag is not present, use the old-school Object#toString test.

1.0.2 / 2015-01-29
=================
  * Fix package.json
  * Improve optimizability of the non-try/catch part.

1.0.1 / 2015-01-29
=================
  * Add early exits for typeof number, or typeof not "object".

1.0.0 / 2015-01-28
=================
  * Initial release.
