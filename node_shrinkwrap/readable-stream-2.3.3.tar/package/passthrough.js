module.exports = require('./readable').PassThrough
