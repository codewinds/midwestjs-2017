require('../../modules/es6.reflect.is-extensible');
module.exports = require('../../modules/_core').Reflect.isExtensible;
