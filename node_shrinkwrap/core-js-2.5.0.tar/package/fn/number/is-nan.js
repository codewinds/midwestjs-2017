require('../../modules/es6.number.is-nan');
module.exports = require('../../modules/_core').Number.isNaN;
