require('../../modules/es6.number.parse-float');
module.exports = parseFloat;
