require('../../modules/es6.function.has-instance');
module.exports = Function[require('../../modules/_wks')('hasInstance')];
