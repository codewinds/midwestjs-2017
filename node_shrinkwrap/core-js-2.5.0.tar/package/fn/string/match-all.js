require('../../modules/es7.string.match-all');
module.exports = require('../../modules/_core').String.matchAll;
