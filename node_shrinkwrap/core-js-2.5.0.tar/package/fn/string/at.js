require('../../modules/es7.string.at');
module.exports = require('../../modules/_core').String.at;
