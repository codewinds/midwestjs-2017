require('../../modules/core.string.escape-html');
module.exports = require('../../modules/_core').String.escapeHTML;
