require('../../../modules/core.string.unescape-html');
module.exports = require('../../../modules/_entry-virtual')('String').unescapeHTML;
