require('../../../modules/es6.string.sub');
module.exports = require('../../../modules/_entry-virtual')('String').sub;
