require('../../../modules/es6.string.sup');
module.exports = require('../../../modules/_entry-virtual')('String').sup;
