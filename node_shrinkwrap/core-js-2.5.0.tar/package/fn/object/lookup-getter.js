require('../../modules/es7.object.lookup-setter');
module.exports = require('../../modules/_core').Object.__lookupGetter__;
