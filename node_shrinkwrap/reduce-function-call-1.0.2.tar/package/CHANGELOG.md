# 1.0.2 - 2016-11-28

- Bump `balanced-match` dependency version
([postcss-cssnext/#327](https://github.com/MoOx/postcss-cssnext/issues/327) - @wtgtybhertgeghgtwtg).

# 1.0.1 - 2014-08-06

* Fix issue with regex and nested call

# 1.0.0 - 2014-08-06

First release
